using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace LeaveManagementSystem.Pages
{
    public class ViewLeaveModel : PageModel
    {
        public string errorMessage = "";
        public List<Leave> listLeave = new List<Leave>();
        
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=LAPTOP-1BBUSSAC\\MSSQL13;Initial Catalog=POC;Integrated Security=True";


                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM LeaveSystem";
                    

                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                            while (reader.Read())
                            {
                                Leave leave = new Leave();
                                leave.firstName = "" + reader.GetString(1);
                                leave.lastName = reader.GetString(2);
                                leave.startLeave = reader.GetDateTime(3);
                                leave.endDate = reader.GetDateTime(4);
                                leave.typeLeave = reader.GetString(5);
                                leave.reason = reader.GetString(6);
                                leave.totalDays = reader.GetInt32(7);
                                leave.totalLeave = reader.GetInt32(8);


                                listLeave.Add(leave);
                            }
                    }

                   

                }

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }
        }


        public class Leave
        {
            public DateTime startLeave;
            public DateTime endDate;
            public String firstName;
            public String lastName;
            public String reason;
            public int totalDays;
            public int totalLeave;
            public String typeLeave;
        }
    }
}
