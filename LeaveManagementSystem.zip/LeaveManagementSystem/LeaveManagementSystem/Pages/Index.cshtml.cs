﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace LeaveManagementSystem.Pages
{
    public class IndexModel : PageModel

    {
        public string errorMessage = "";
        public string successMessage = "";
        private readonly ILogger<IndexModel> _logger;
        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }

        public void OnPost()
        {

            DateTime StartLeave = Convert.ToDateTime(Request.Form["StartLeave"]);
            DateTime EndDate = Convert.ToDateTime(Request.Form["EndDate"]);
            // DateTime TotalDays = Convert.ToDateTime(Request.Form["TotalDays"]);
            int TotalDays = Convert.ToInt32(Request.Form["TotalDays"]);
            int TotalLeave = Convert.ToInt32(Request.Form["TotalLeave"]);
            string FirstName = Request.Form["FirstName"];
            string LastName = Request.Form["LastName"];
            string TypeLeave = Request.Form["TypeLeave"];
            string Reason = Request.Form["Reason"];


            DateTime date = StartLeave.Date;
            DateTime date1 = EndDate.Date;

            //TotalDays = Convert.ToDateTime((EndDate.Date - StartLeave.Date).TotalDays);
            try
            {
                String connectionString = "Data Source=LAPTOP-1BBUSSAC\\MSSQL13;Initial Catalog=POC;Integrated Security=True";


                SqlConnection connection = new SqlConnection(connectionString);

                string sql = "INSERT INTO LeaveSystem (FirstName,LastName,StartLeave,EndDate,TypeLeave,Reason,TotalDays,TotalLeave) " +
                    "VALUES(@FirstName,@LastName,@StartLeave,@EndDate,@TypeLeave,@Reason,@TotalDays,@TotalLeave)";

                SqlCommand cmd = new SqlCommand(sql, connection);

                cmd.Parameters.AddWithValue("@FirstName", FirstName);
                cmd.Parameters.AddWithValue("@LastName", LastName);
                cmd.Parameters.AddWithValue("@StartLeave", date);
                cmd.Parameters.AddWithValue("@EndDate", date1);
                cmd.Parameters.AddWithValue("@TypeLeave", TypeLeave);
                cmd.Parameters.AddWithValue("@Reason", Reason);
                cmd.Parameters.AddWithValue("@TotalDays", TotalDays);
                cmd.Parameters.AddWithValue("@TotalLeave", TotalLeave);

                connection.Open();

                cmd.ExecuteNonQuery();

                connection.Close();

                successMessage = "Added";
                Response.Redirect("/ViewLeave");
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }

        }
    }
    }

